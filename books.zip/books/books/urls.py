"""
URL configuration for books project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from bookapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.BookListView.as_view()),
    path('c/', views.BookCreateView.as_view()),
    path('r/<int:pk>', views.BookRetrieveView.as_view()),
    path('u/<int:pk>', views.BookUpdateView.as_view()),
    path('d/<int:pk>', views.BookDestroyView.as_view()),
    path('lc', views.BookListCreateView.as_view()),
    path('ru/<int:pk>', views.BookRetrieveUpdateView.as_view()),
    path('rd/<int:pk>', views.BookRetrieveDeleteView.as_view()),
    path('rud/<int:pk>', views.BookRUDView.as_view()),
    
    
    

]
