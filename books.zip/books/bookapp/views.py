from django.shortcuts import render
from .serializers import *
from .models import Book
from rest_framework.response import Response
from rest_framework.generics import ListAPIView, CreateAPIView, RetrieveAPIView, UpdateAPIView, DestroyAPIView, ListCreateAPIView, RetrieveUpdateAPIView, RetrieveDestroyAPIView, RetrieveUpdateDestroyAPIView


class BookListView(ListAPIView):
    queryset=Book.objects.all()
    serializer_class=BookSerializer

class BookCreateView(CreateAPIView):
    queryset=Book.objects.all()
    serializer_class=BookSerializer

class BookRetrieveView(RetrieveAPIView):
    queryset=Book.objects.all()
    serializer_class=BookSerializer

class BookUpdateView(UpdateAPIView):
    queryset=Book.objects.all()
    serializer_class=BookSerializer

class BookDestroyView(DestroyAPIView):
    queryset=Book.objects.all()
    serializer_class=BookSerializer

class BookListCreateView(ListCreateAPIView):
    queryset=Book.objects.all()
    serializer_class=BookSerializer

class BookRetrieveUpdateView(RetrieveUpdateAPIView):
    queryset=Book.objects.all()
    serializer_class=BookSerializer

class BookRetrieveDeleteView(RetrieveDestroyAPIView):
    queryset=Book.objects.all()
    serializer_class=BookSerializer

class BookRUDView(RetrieveUpdateDestroyAPIView):
    queryset=Book.objects.all()
    serializer_class=BookSerializer